#include "lista.h"
#include "menu.h"


int main()
{
		inicializar_juego();
		menu();
		return 0;
	
}




void inicializar_juego() 
{ 
	
	lista = NULL;
	leer_archivo();
	ordenar_vector();
}


void jugar(){
	
	int n;
	int nivel;
	int jugada;
	random();
	for (nivel = 0; nivel < MAX; nivel++) {
		printf("Nivel %d\n", nivel+1);

	
		
		visualizar_elementos(lista, nivel);
		
		
		
		sleep(2);
		
		
		system("cls");
		
		
		recorrer_y_preguntar_elementos( lista, nivel );
	
		
	
	}
}	

