#include<string.h>
#include<stdbool.h>
#define ARBOL 100
#include "ascii.h"

typedef char tStringg [300];




typedef struct structura{
	tStringg clave;
}item;

typedef struct Elemento{
	item dato;
	struct Elemento *padre,*izq, *der;
}nodo;

typedef struct{
	nodo *raiz;
}ArbolBin;

tStringg var,var1,var2,var3;

nodo* crearNodo(item nombre){
	nodo *a;
	a=(nodo*)malloc(sizeof(nodo));
	a->dato = nombre;
	a->padre = NULL;
	a->izq = NULL;
	a->der = NULL;
	return a;
}

void inicializarArbolBin(ArbolBin *arb){
	arb->raiz = NULL;
}


void mostrarArbolBinRec(nodo *nodo, tStringg cad){
	printf("%s\n", nodo->dato.clave);
	
	/*Para el hijo izquierdo*/ 
	if(nodo->izq!=NULL){
		char cad2[ARBOL]; strcpy(cad2,cad);
		if(nodo->der!=NULL){
			printf("%s", cad);
			strcat(cad2, "      ");
			mostrarArbolBinRec(nodo->izq,cad2);
		}else{
		printf("%s", cad);
		strcat(cad2, "      ");
		mostrarArbolBinRec(nodo->izq,cad2);
		}
	}
	/*pal hijo derecho*/
	if(nodo->der!=NULL){
		char cad3[ARBOL]; strcpy(cad3,cad);
		printf("%s", cad);
		strcat(cad3, "      ");
		mostrarArbolBinRec(nodo->der,cad3);
		
	}
}

void mostrarArbolBin(ArbolBin arb){
	tStringg cad;
	if(arb.raiz==NULL){
		printf("El arbol esta vacio!!!\n");
	}else {
		mostrarArbolBinRec(arb.raiz, cad);
	}
}

void cargarArbol(){
	ArbolBin arbol;
	inicializarArbolBin(&arbol);
	
	/*Construccion del arbol*/
	
	item nombre;
	nodo *nodo1, *nodo2, *nodo3, *nodo4, *nodo5;
	sprintf(var3,"  _               ___     \n | |   ___ ___   | __|   \n | |__/ -_) _ %c  | _|   _ \n |____%c___%c___/  |_|   (_)\n",92,92,92);
	strcpy(nombre.clave,var3) ; nodo1  = crearNodo(nombre); arbol.raiz    = nodo1;
	
	sprintf(var2,"  __  __          _    ___   \n |  %c/  |__ ___ _(_)  | __|   \n | |%c/| / _` %c %c / |  | _|   _ \n |_|  |_%c__,_/_%c_%c_|  |_|   (_)\n",92,92,92,92,92,92,92);
	strcpy(nombre.clave,var2); nodo2  = crearNodo(nombre); nodo1->izq    = nodo2; nodo2->padre = nodo1;
	
	sprintf(var1,"  _                ___     \n | |   ___ ___    / __|    \n | |__/ -_) _ %c  | (__   _ \n |____%c___%c___/   %c___| (_)\n",92,92,92,92);
	strcpy(	nombre.clave,var1) ; nodo3  = crearNodo(nombre); nodo3->padre  = nodo1; nodo1->der   = nodo3;
	
	sprintf(var, "\n  _____ _               ___     \n |_   _| |_  ___ ___   | __|    \n   | | | ' %c/ -_) _ %c  | _|   _ \n   |_| |_||_%c___%c___/  |___| (_)\n",92,92,92,92);
	strcpy(nombre.clave,var); nodo4  = crearNodo(nombre); nodo4->padre  = nodo2; nodo2->izq   = nodo4;

creadores();
mostrarArbolBin(arbol);
}
