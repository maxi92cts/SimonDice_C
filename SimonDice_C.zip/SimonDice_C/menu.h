#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>
#include <string.h>
#include <windows.h>
#include <time.h>
#include <conio.h>
#include "arbol.h"


void menu();
void jugar();

int opcion;


void menu()
{
	/*LLAMAMOS AL ARBOL CON NUESTROS NOMBRES*/
	cargarArbol();
	printf("\n\n\n");
	printf("----------------------------------------------------------------------------------------\n");
	menu_edit();
	while(1)
	{	
		jugar_ascii();
		ranking_ascii();
		salir_ascii();
		printf("\n\n");
		scanf("%d",&opcion);
		printf("\n\n");
		switch(opcion)
		{
			case 1: system("cls");
					ingresar_datos_jugador();
					jugar();
					break;
			case 2: imprimir_vector();
					printf("\n\n");
					break;
			case 3: exit(1);
					break;
			default: printf("Opcion incorrecta. Ingrese de nuevo");
		
			}
		}
}




