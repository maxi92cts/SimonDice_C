#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>
#include <string.h>
#include <windows.h>
#include <time.h>
#include <conio.h>
#include "archivo.h"
#define MAX 30


typedef struct{
	int x;
}tElementos;

typedef struct nodo{
	tElementos elemento;
	struct nodo * siguiente;
}tLista;

tLista * lista;
tElementos numero;
int x, i;
int puntoXNumero, puntoXNivel, puntuacionTotal, nivelMax;



bool lista_vacia(tLista*);
void visualizar_elementos(tLista*, int);
void recorrer_y_preguntar_elementos(tLista*, int);
void insertar_elemento(int);
void inicializar_lista();
void insertar_primero(int);
void insertar_adelante(int);
void inicializar_juego();
void jugar();
void puntuaciones();
void random();

bool lista_vacia(tLista * pLista) {
		return ( pLista == NULL );
}


void visualizar_elementos( tLista * pLista, int nivel ) {
	tLista * aux;
	aux = pLista;
	int k = 0;
	if ( !lista_vacia( pLista ) ) {
		printf( "\n*** Numeros en la lista ***\n" );
		while(aux != NULL && k<=nivel) {
			printf("%d - ", aux->elemento.x);
			Sleep(1);
			aux = aux->siguiente;
			k++;
		}
	}
}

void recorrer_y_preguntar_elementos( tLista * pLista, int nivel ) {
	tLista * aux;
	aux = pLista;
	int k = 0;
	if ( !lista_vacia( pLista ) ) {
		while(aux != NULL && k<=nivel) {
			printf("\x1B[33m");
			printf("Ingrese un numero: ");
			printf("\x1B[37m");
			scanf("%d",&x);
			k++;
			if(x != aux->elemento.x){
				printf("\033[0;31m");
				printf("\nERROR: Numero ingresado = %d  - Numero esperado = %d ",x,pLista->elemento.x);
				printf("\x1B[37m");
				printf("\n");
				puntuaciones();
				guardar_datos_jugador(jugador.nombre, jugador.apellido, puntuacionTotal, nivelMax);
				realizar_operaciones();
				imprimir_puntuacion_jugador();
				exit(1);
			}
			puntoXNumero = puntoXNumero + 3;
			aux = aux->siguiente;
		}
		puntoXNivel = puntoXNivel + 5;
		nivelMax++;
		jugador.nivelMaximoAlcanzado = nivelMax;
	}
}

void inicializar_lista() 
{ 
	lista = NULL;
}

void insertar_elemento( int pNumero ) {
	if ( lista == NULL ){
		insertar_primero( pNumero );
	}else {
		insertar_adelante( pNumero );
	}
}

void insertar_primero( int pNumero ) {
	
	tLista * nuevoNodo;
	
	nuevoNodo = ( tLista * ) malloc( sizeof( tLista ));
	
	nuevoNodo->elemento.x = pNumero;

	nuevoNodo->siguiente = NULL;

	lista = nuevoNodo;

}

void insertar_adelante( int pNumero ) {
	
	tLista * nuevoNodo;

	nuevoNodo = ( tLista * ) malloc( sizeof( tLista ) );

	nuevoNodo->elemento.x = pNumero;
	
	nuevoNodo->siguiente = lista;

	lista = nuevoNodo;
	
}

void random(){
	int n;
	srand(time(NULL));
	for (n = 0; n < MAX; n++) {
		x = rand() % 6;
		insertar_elemento(x);
	}
}

void puntuaciones(){
		puntuacionTotal = puntoXNivel +  puntoXNumero;
		jugador.puntuacion = puntuacionTotal;
		printf("\nSu puntuacion total es de: %d\n",puntuacionTotal);
}
