#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>
#include <string.h>
#define VECTOR 200



typedef char tString[100];
int numeroJugador = 0;


void ingresar_datos_jugador();
void guardar_datos_jugador(tString, tString, int, int);
void ordenar_vector();
void imprimir_vector();
void imprimir_puntuacion_jugador();

typedef struct {
	tString nombre;
	tString apellido;
	int puntuacion;
	int nivelMaximoAlcanzado;  
}tJugador;

typedef struct{
	tJugador vectorJuego[VECTOR]; 
}tVector;


tJugador jugador;
tVector JUGADOR;



void ingresar_datos_jugador(){
	printf("Ingrese su nombre: ");
	scanf("%s",&jugador.nombre);
	printf("Ingrese su apellido: ");
	scanf("%s",&jugador.apellido);
}
	
	
void guardar_datos_jugador(tString nombre ,tString apellido ,int puntuacion ,int nivelMaximoAlcanzado )
{
		strcpy(JUGADOR.vectorJuego[numeroJugador].nombre, nombre);
		strcpy(JUGADOR.vectorJuego[numeroJugador].apellido, apellido);
		JUGADOR.vectorJuego[numeroJugador].puntuacion = puntuacion;
		JUGADOR.vectorJuego[numeroJugador].nivelMaximoAlcanzado = nivelMaximoAlcanzado;
		numeroJugador++;
}
	

void ordenar_vector()
{
	int i, j;
	tJugador aux;
	
	
	for(i=0; i < numeroJugador; i++)
	{
		for(j=0; j < numeroJugador; j++)
		{
			if(JUGADOR.vectorJuego[j+1].puntuacion > JUGADOR.vectorJuego[j].puntuacion){
				aux = JUGADOR.vectorJuego[j];
				JUGADOR.vectorJuego[j] = JUGADOR.vectorJuego[j+1];
				JUGADOR.vectorJuego[j+1] = aux;
				
			}
		}
				
	}
}

void imprimir_vector()
{
	int i;
	for(i=0; i<numeroJugador; i++)
	{
		printf("\t%d - NOMBRE: %s --- APELLIDO: %s --- PUNTUACION: %d --- NIVEL MAX ALCANZADO: %d\n",
		i+1,JUGADOR.vectorJuego[i].nombre, JUGADOR.vectorJuego[i].apellido, JUGADOR.vectorJuego[i].puntuacion, JUGADOR.vectorJuego[i].nivelMaximoAlcanzado);
		printf("\n");
	}
	
}

void imprimir_puntuacion_jugador()
{
	printf("\nNOMBRE: %s --- APELLIDO: %s --- PUNTUACION: %d --- NIVEL MAX ALCANZADO: %d\n", jugador.nombre, jugador.apellido, jugador.puntuacion, jugador.nivelMaximoAlcanzado);
}
