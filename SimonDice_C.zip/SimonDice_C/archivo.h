#include "vector.h"






void leer_archivo();
void realizar_operaciones();
void fin_archivo();


FILE * archivo;

void leer_archivo()
{
	int n;
	
	archivo = fopen("SimonDice.dat", "rb");
	if(archivo != NULL)
	{
		while (!feof(archivo)) 
		{
			n = fread(&JUGADOR.vectorJuego[numeroJugador],sizeof(tJugador), 1, archivo);
			if (n>0)
			{
				numeroJugador++;
			}
		}
		
	}
	fin_archivo();
}


void realizar_operaciones()
{
	archivo = fopen("SimonDice.dat","ab");
	fwrite(&jugador, sizeof(tJugador), 1, archivo);
	fin_archivo();
}

void fin_archivo()
{
	fclose(archivo);
}
